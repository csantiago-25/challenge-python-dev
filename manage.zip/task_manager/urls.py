# task_manager/urls.py

from django.contrib import admin
from django.urls import path, include

# Asegúrate de que estás incluyendo las URLs de la aplicación `tasks`
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('tasks.urls')),  # Importa las URLs desde la aplicación `tasks`
]
