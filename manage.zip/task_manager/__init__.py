from .celery_config import app as celery_app
