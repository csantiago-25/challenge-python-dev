from __future__ import absolute_import, unicode_literals
import os
from celery import Celery

# Establecer la configuración de Django para Celery
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'task_manager.settings')

app = Celery('task_manager')

# Configurar Celery para que use las configuraciones de Django
app.config_from_object('django.conf:settings', namespace='CELERY')

# Descubrir tareas de aplicaciones Django automáticamente
app.autodiscover_tasks()
